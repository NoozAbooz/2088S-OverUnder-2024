#include "main.h"

void rollerAuton();
void dispenseDiscs();