#ifndef SELECTION_H
#define SELECTION_H

// Makes auton selection and the selector script global
extern void selectorInit();
extern int autonSelection;

#endif